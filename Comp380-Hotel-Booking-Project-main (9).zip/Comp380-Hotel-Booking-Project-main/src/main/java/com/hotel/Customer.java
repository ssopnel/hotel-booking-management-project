package com.hotel;
//Joseph Wythe
public class Customer implements Identifiable{
    private int customerID;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;

    public Customer(int customerID, String firstName, String lastName, String email, String phoneNumber){
        this.customerID = customerID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    public Customer(String firstName, String lastName, String email, String phoneNumber, String password){
        CustomerDao dao = new CustomerDao();
        int randomID;
        while(true){
            randomID = (int)(Math.random() * 100000);
            if(dao.searchID(String.valueOf(randomID)) == false){
                break;
            }
        }
        this.customerID = randomID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    public Customer(){
    this.customerID=-1;
   }

   public int getCustomerID(){
    return this.customerID;
   }

   public String getFirstName(){
    return this.firstName;
   }

   public String getLastName(){
    return this.lastName;
   }

   public String getEmail(){
    return this.email;
   }

    public String getPhoneNumber(){
     return this.phoneNumber;
    }

    public void setFirstName(String firstName){
        this.firstName = firstName;
    }

    public void setLastName(String lastName){
        this.lastName = lastName;
    }

    public void setEmail(String email){
        this.email = email;
    }

    public void setPhoneNumber(String phoneNumber){
        this.phoneNumber = phoneNumber;
    }

    public String getIdentifier(){
        return String.valueOf(this.customerID);
    }


}
