package com.hotel;
//joseph wythe
public class Employee implements Identifiable{
    public int employeeID;
    public String firstName;
    public String lastName;
    public String email;
    private String position;
    private String password;
    
    public Employee (int employeeID, String firstName, String lastName, String email, String position){
        this.employeeID = employeeID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.position = position;
    }

    public Employee (String fullName, String email, String password){
        this.firstName = fullName;
        this.lastName = "";
        this.email = email;
        this.password = password;
    }

    public Employee(){
        this.employeeID = -1;
    }

    public int getEmployeeID(){
        return this.employeeID;
    }

    public String getFirstName(){
        return this.firstName;
    }

    public String getLastName(){
        return this.lastName;
    }

    public String getEmail(){
        return this.email;
    }

    public String getPosition(){
        return this.position;
    }

    public String getPassword(){
        return this.password;
    }

    public void setFirstName(String firstName){
        this.firstName = firstName;
    }

    public void setLastName(String lastName){
        this.lastName = lastName;
    }

    public void setEmail(String email){
        this.email = email;
    }

    public void setPosition(String position){
        this.position = position;
    }

    public Login createLogin(String username, String password){
        return new Login(username, password, true);
    }

    public String getIdentifier(){
        return String.valueOf(this.employeeID);
    }
    
}
