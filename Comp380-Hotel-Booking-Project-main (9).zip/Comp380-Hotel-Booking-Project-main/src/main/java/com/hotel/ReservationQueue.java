package com.hotel;
/**
 * Allows creating queue of QueueItems. Uses linked list.
 *
 * @author Max Brown
 */

public class ReservationQueue{
	/** First item in queue. */
	private QueueItem first;
	/** How many items are in queue. */
	private int length;
	
	/**
	 * Blank constructor. Uses default length of zero and contains no QueueItems.
	 * 
	 *
	 */
	public ReservationQueue(){
		length = 0;
	}
	
	/**
	 * Constructor adds first QueueItem and sets length to 1.
	 * @param first QueueItem that 
	 */
	public ReservationQueue(QueueItem first){
		this.first = first;
		this.length = 1;
	}
	
	/** 
	 * Removes item at front of queue and returns it. 
	 * @return Item at front of queue
	 */
	public Reservation remove(){
		if(length == 0){
			return null;
		}
		QueueItem temp = this.first;
		this.first = temp.getNext();
		length = length - 1;
		return temp.getData();
	}
	
	/** 
	 * Adds new item to back of queue.
	 * @param newest QueueItem being added.
	 */
	public void add(Reservation newest){
		if(length == 0){
			this.first = new QueueItem(newest);
			length = 1;
		}
		else{
			QueueItem current = this.first;
			while(current.getNext() != null){
				current = current.getNext();
			}
			current.setNext(new QueueItem(newest));
			length = length + 1;
		}
		
	}
	
	/** 
	 * Returns item at front of queue without removing it.
	 * @return Item at front of queue.
	 */
	public Reservation getFirst(){
		if(length == 0){
			return null;
		}
		else{
			return first.getData();
		}
	}
	
	public int getLength(){
		return this.length;
	}
	
}