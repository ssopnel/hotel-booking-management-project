package com.hotel;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileWriter;
import java.util.ArrayList;

/**  
 * Generic Dao class. Reads and writes to text file in order to store objects as Strings representing the object's variables.
 * 
 *
 * @author Max Brown
 * @param <T> Object type being stored in file.
 */
public abstract class Dao<T extends Identifiable>{
	
	/** Path where objects will be stored*/
	private String filePath; 
	
	/** List of variables stored in each object. 
	 * Names will be used inside text file. First attribute should be unique identifier. 
	 * Example: {"Room Number","Room Type","Smoking","Handicap"}
	 */
	private String[] attributes; 
								
	
	
	/** Checks if object is already in file. If not, appends the object to the end of the file. Objects separated by ----.
	 * @param t Object being stored as text.
	 */
	public void create(T t){
		try(FileWriter writer = new FileWriter(getFilePath(),true)){
			String[] variables = convert(t);
			if(!read(t.getIdentifier()).getIdentifier().equals("-1")){
				System.out.println("Already exists");
				return;
			}
			for(int i = 0; i < getAttributes().length;i++){
				writer.write(getAttributes()[i] + ": " + variables[i] + "\n");
			}
			writer.write("----\n");
			System.out.println("Created");
			
		}
		catch(IOException e){
			e.getMessage();
		}
		
	}
	
	/** Finds the object in file using unique identifier. Creates and populates the object with its variables then returns it. 
	 * @param identifier Unique variable used to find object in file.
	 * @return Object with variables from text file.
	 */
	public T read(String identifier){
		String[] variables = new String[getAttributes().length];
		try(Scanner scanner = new Scanner(new File(getFilePath()))){
			while(scanner.hasNextLine()){
				String s = scanner.nextLine();
				String prefix = getAttributes()[0] + ": ";
					if(s.startsWith(prefix) && s.substring(prefix.length()).equals(identifier)){
						variables[0] = s.substring(prefix.length());
						for(int i = 1; i < getAttributes().length; i++){
							String data = scanner.nextLine();
							variables[i] = data.substring(getAttributes()[i].length() + 2);
						}
						break;
				}
			}	
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
		}
		if(variables[0] == null){
			//System.out.println("Not found");
		}
		return convert(variables);
		
	}
	
	/** Reads all objects in file. Finds updated object using identifier. Updates object with changed variables. Rewrites whole file. 
	 * @param t Object being updated.
	 */
	public void update(T t){
		ArrayList<T> list = readAll();
		int i = 0;
		while(i < list.size()){
			if(convert(list.get(i))[0].equals(convert(t)[0])){
				break;
			}
			i++;
		}
		if(i >= list.size()){
			System.out.println("Could not find");
			return;
		}
		else{
			list.set(i,t);
			writeAll(list);
		}
	}
	
	/** Reads all objects in file. Deletes desired object using identifier. Rewrites whole file without the deleted object.
	 * @param t Object being deleted.
	 */
	public void delete(T t){
		ArrayList<T> list = readAll();
		int i = 0;
		while(i < list.size()){
			if(convert(list.get(i))[0].equals(convert(t)[0])){
				break;
			}
			i++;
		}
		if(i >= list.size()){
			System.out.println("Could not find");
			return;
		}
		else{
			list.remove(i);
			writeAll(list);
		}
	}
	
	/** Reads all objects in a file and returns ArrayList of them. Helper method used in update() and delete(). 
	 * @return ArrayList with all written objects in file.
	 */
	public ArrayList<T> readAll(){
		ArrayList<T> list = new ArrayList<T>();
		try(Scanner scanner = new Scanner(new File(getFilePath()))){ 
			while(scanner.hasNextLine()){
				String s = scanner.nextLine();
				String prefix = getAttributes()[0] + ": ";
				if(s.startsWith(prefix)){
					String[] variables = new String[getAttributes().length];
					variables[0] = s.substring(prefix.length());
					for(int i = 1; i < getAttributes().length; i++){
						s = scanner.nextLine();
						variables[i] = s.substring(getAttributes()[i].length() + 2);
					}
					list.add(convert(variables));
				}
			}
			
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
			
		}
		return list;
	}
	
	/** Writes all objects from ArrayList to the file using create() method. Helper method used in update() and delete(). 
	 * @param list ArrayList of objects to be written to file.
	 */
	private void writeAll(ArrayList<T> list){
		try(FileWriter writer = new FileWriter(getFilePath())){
		}catch(IOException e){
			System.out.println(e.getMessage());
		}
		
		for(int i = 0; i < list.size(); i++){
			create(list.get(i));
		}
	}

	protected boolean searchID(String id){
		try(Scanner scanner = new Scanner(new File(getFilePath()))){
			while(scanner.hasNextLine()){
				String s = scanner.nextLine();
				if(s.contains("ID: ")){
					s = s.substring(s.indexOf("ID: ") + 4);
					if(s.equals(id)){
						return true;
					}
				}
			}
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
		}
		return false;
	}
	
	/** Creates array of Strings and fills each slot with a variable stored in the object. 
	 * @param t Object to be converted.
	 * @return String representation of object's variables.
	 */
	protected abstract String[] convert(T t);
	
	/** Takes array of Stings and creates an object using these Strings. Must convert Strings to appropriate variables.  
	 * @param variables Strings to be converted to object's instance variables.
	 * @return Object with its instance variables created from array variables.
	 */
	protected abstract T convert(String[] variables);
	
	/** Gets file path where objects are stored as a String.
	 * @return A String containing the file path where objects are stored.
	 */
	protected abstract String getFilePath();
	/** Gets array of Strings that has names of instance variables stored in object.
	 * @return Array of Strings that contains names of instance variables.
	 */
	protected abstract String[] getAttributes();
	
	
	
}
