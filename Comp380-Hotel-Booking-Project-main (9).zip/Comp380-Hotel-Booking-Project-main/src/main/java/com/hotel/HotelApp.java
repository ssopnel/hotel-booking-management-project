package com.hotel;

import javafx.application.Application;
import javafx.stage.Stage;

/*
   the main method for the hotel application. Class allows to start from her.
*/
public class HotelApp extends Application 
{
    
    /*
      Method to create the the main window for the guest or staff to choose where to go
    */
    @Override
    public void start(Stage stage) 
    {
        // Link to window 
        SceneManager.setStage(stage);
        
        // Display main window and introduce the user to the hotel("Name has not been decided")
        SceneManager.switchTo("WelcomeView.fxml", "Welcome to Hotel");
        
        //show the actual site
        stage.show();
    }

    /*
      The main method to come back to when running the program
    */
    public static void main(String[] args) 
    {
        // Launch is a built-in JavaFX method that configures the graphics engines
        launch();
    }
}

//Name for hotel must be changes. discuss with teammates
//Seems simple but needs sopnel input if is correct
