package com.hotel;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/** Dao class used for Login. Stores login data to a text file.
 *
 *
 * @author Max Brown
 *
 */
public class LoginDao extends Dao<Login>{
	
	/** Path where Login data is being stored. */
	private String filePath = "data/logins.txt"; 
	/** List of variables stored in login. */
	private String[] attributes = {"Username", "Password", "Employee", "ID"}; 
	/**
	 * Constructor.
	 */
	public LoginDao(){
		
	}
	
	/**	
	 * Converts login object into Array of Strings
	 * @param t Login object being converted.
	 * @return Array that contains all of t's instance variables as Strings.
	 */
	protected String[] convert(Login t){
		String[] variables = new String[attributes.length];
		variables[0] = String.valueOf(t.getUsername());
		variables[1] = String.valueOf(t.getPassword());
		variables[2] = String.valueOf(t.getIsEmployee());
		variables[3] = String.valueOf(t.getID());
		return variables;
	}
	
	/** 
	 * Creates new Login object. Converts elements in Array variables into appropriate type then passes to Login constructor.	 
	 * @param variables Array of Strings which represents instance variables of Login object.
	 * @return Login object created from variables Array.
	 */
	protected Login convert(String[] variables){
		if(variables[0] == null){
			return new Login();
		}
		String username = variables[0];
		String password = variables[1];
		boolean isEmployee = Boolean.parseBoolean(variables[2]);
		int ID = Integer.parseInt(variables[3]);
		return new Login(username, password, isEmployee, ID);
	}
	
	/**
	 * Gets filePath where Login objects are stored.
	 * @return filePath as String.
	 */
	protected String getFilePath(){
		return filePath;
	}
	
	/**
	 * Gets array of Strings that has names of instance variables stored in Login.
	 * @return Array of Strings that contains names of instance variables.
	 */
	protected String[] getAttributes(){
		return attributes;
	}
	
	/**
	 * Searches file for ID specified. Returns whether ID was found.
	 * @param id ID being searched for as String.
	 * @return True when ID found in file. False otherwise.
	 */
	protected boolean searchID(String id){
		try(Scanner scanner = new Scanner(new File(getFilePath()))){
			while(scanner.hasNextLine()){
				String s = scanner.nextLine();
				if(s.indexOf("ID: " + id) != -1){
					return true;
				}
			}
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
		}
		return false;
	}
}