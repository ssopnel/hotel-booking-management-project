package com.hotel;

import java.util.ArrayList;
/** Room object that represents the rooms in the hotel.
 * 
 * 
 *
 *@author Max Brown
 */
public class Room implements Identifiable{
    
	/** Number of the room. Identifier. First digit represents floor. */
	private int roomNumber; 
	/** Whether smoking is allowed. */
	private boolean smoking;
	/** Whether there are amenities for people who are handicapped. */
    private boolean handicap; 
	/** Kind of room. King, Queen, 2 beds. */
	private String roomType; 
	/** Reservations that have been confirmed by staff for this room in order by date.*/
	private ArrayList<Reservation> reservations;
	
	/**
	 * Creates Room object using all parameters listed.	 
	 * @param roomNumber Number of the room.
	 * @param roomType Type of room.
	 * @param smoking Whether smoking is allowed.
	 * @param handicap Whether there are amenities for people who are handicapped.
	 */
	public Room(int roomNumber, String roomType, boolean smoking, boolean handicap){
		this.roomNumber = roomNumber;
		this.roomType = roomType;
		this.smoking = smoking;
		this.handicap = handicap;
		this.reservations = new ArrayList<>();
	}
	
	/**
	 * Creates Room object with smoking and handicap defaulted to false.
	 * @param roomNumber Number of the room.
	 * @param roomType Type of room.
	 */
	public Room(int roomNumber, String roomType){
		this.roomNumber = roomNumber;
		this.roomType = roomType;
		this.smoking = false;
		this.handicap = false;
	}
	
	/**
	 * Checks list of reservations for this room to see if new reservation can fit.
	 * @param r Reservation attempting to be added.
	 * @return Whether the reservation can be added.
	 */
	public boolean isAvailable(Reservation r){
		for(int i = 0; i < reservations.size(); i++){
			if((reservations.get(i).conflictsWith(r))){
				return false;
			}
		}
		return true;
	}
	
	/** Invalid room used for error handling */
	public Room(){
		this.roomNumber = -1;
	}
	
	/**
	 * Adds a Reservation to the list of reservations in this room. 
	 * @param res Reservation being added to the Room
	 *
	 */
	public void addReservation(Reservation res){
		for(int i = 0; i < reservations.size(); i++){
			if(res.isBefore(reservations.get(i))){
				reservations.add(i, res);
				return;
			}
		}
		reservations.add(res);
	}
	
	/**
	 * Gets number of the room.
	 * @return The room's number.
	 */
	public int getRoomNumber(){
		return this.roomNumber;
	}
	
	/**
	 * Gets the type of room.
	 * @return The room's type.
	 */
	public String getRoomType(){
		return this.roomType;
	}
	
	/**
	 * Gets whether handicap amenities are available.
	 * @return Handicap status of room.
	 */
	public boolean getHandicap(){
		return this.handicap;
	}
	
	/**
	 * Gets whether smoking is allowed in room.
	 * @return Smoking status of room.
	 */
	public boolean getSmoking(){
		return this.smoking;
	}
	
	/**	
	 * Converts unique identifier of room to a String.
	 * @return The unique identifier, the room number, as a String.
	 */
	public String getIdentifier(){
		return String.valueOf(roomNumber);
	}
	
	
	public ArrayList<Reservation> getReservations(){
		return this.reservations;
	}
	
}
