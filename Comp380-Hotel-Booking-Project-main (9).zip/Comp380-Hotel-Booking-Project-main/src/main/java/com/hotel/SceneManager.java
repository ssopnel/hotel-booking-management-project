package com.hotel;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

/*.
  Class that help changing the windows with the proper selection and the main window
*/
public class SceneManager 
    {
        // Tracks the main window 
        private static Stage primaryStage;

        /*
        Stores the main window so the controller files can use it to switch screens.
        */
        public static void setStage(Stage stage) 
        {
        primaryStage = stage;
        }

        /*
       
        Method to replace the window to user choice and display proper window. 
        fxmlfile is for proper file path 
        title is for which display for that file. 
        */
       @SuppressWarnings("CallToPrintStackTrace")
    public static void switchTo(String fxmlFile, String title)
        {
            try 
            {
                
                //Load the proper FXML file layer layout
                FXMLLoader loader = new FXMLLoader(SceneManager.class.getResource("/" + fxmlFile));
            
                
                //Create a window wrap based on the loaded layout
                Scene scene = new Scene(loader.load());
            
                // Dynamically adjust window 
                primaryStage.setTitle(title);
                primaryStage.setScene(scene);
            
                
                //Format the frame to the center
                primaryStage.centerOnScreen();
            } 
            
            catch (IOException e)
            {
                
                //A catch to display error message due to FXML file path incorrect or missing
                System.err.println("Navigation error loading file descriptor: " + fxmlFile);
                e.printStackTrace();
            }
    }
}
