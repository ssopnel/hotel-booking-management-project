package com.hotel.controller;

import com.hotel.SceneManager;
import com.hotel.Reservation;

import java.util.Optional;

import com.hotel.BookingData;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;



/*
  Controls operations for the master registration registry view grid layout system.
  
*/
public class EmployeeDashboardController {
    @FXML private Label welcomeStaffLabel;
    @FXML private TableView<Reservation> reservationTable;
    @FXML private TableColumn<Reservation, String> colGuest;
    @FXML private TableColumn<Reservation, String> colRoomType;
    @FXML private TableColumn<Reservation, String> colCheckIn;
    @FXML private TableColumn<Reservation, String> colCheckOut;
    @FXML private TableColumn<Reservation, String> colStatus;
    @FXML private ComboBox<String> statusUpdateBox;
    private ComboBox<String> rooms;
  
   

    /**
     * Configures grid structures and binds table columns directly to data model variables.
     */ 
    @FXML
    public void initialize() {
        if (welcomeStaffLabel != null) {
            welcomeStaffLabel.setText("Active Session Terminal: " + EmployeeLoginController.loggedInStaff);
        }

        // Map column layouts directly to structural Reservation bean field name markers
        colGuest.setCellValueFactory(new PropertyValueFactory<>("guestUsername"));
        colRoomType.setCellValueFactory(new PropertyValueFactory<>("roomType"));
        colCheckIn.setCellValueFactory(new PropertyValueFactory<>("checkIn"));
        colCheckOut.setCellValueFactory(new PropertyValueFactory<>("checkOut"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        // Hook the layout grid frame straight to the live master list data repository container
        reservationTable.setItems(BookingData.masterList);
        
        // Load target action options into status modifier combo tools
        statusUpdateBox.getItems().addAll("Confirmed", "Checked In", "Checked Out", "Cancelled");
    }

    /**
     * Updates tracking state variables on a highlighted matrix row entry element.
     */
    @FXML
    private void handleUpdateStatus() {
        // Collect highlighted element index tokens out of our active grid window layer
        Reservation selected = reservationTable.getSelectionModel().getSelectedItem();
        String targetStatus = statusUpdateBox.getValue();

        if (selected == null || targetStatus == null) {
            showAlert(Alert.AlertType.WARNING, "Selection Required", "Please select a table row entry and target status modifier.");
            return;
        }

        // Apply state updates to the data item
        selected.setStatus(targetStatus);
        
        // Force the TableView interface component grid to redraw its cells to display the updated text string values
        reservationTable.refresh();
        showAlert(Alert.AlertType.INFORMATION, "Record Shifted", "Reservation tracking token marked: " + targetStatus);
    }

    /**
     * Deletes a selected reservation entry record completely out of the shared runtime database array.
     */
    @FXML
    private void handleDeleteReservation() {
        Reservation selected = reservationTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "Selection Required", "Please make a selection from the list of reservations!");
            return;
        }

      //asks to confirm they want to delete the reservation
       Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
       confirmation.setTitle("Confirm Deletion");
       confirmation.setContentText("Are you sure you want to delete this reservation entry? This action cannot be undone.");

       Optional<ButtonType> result = confirmation.showAndWait();


      //if they select OK, the entry is removed from the table
      
       if(result.get() == ButtonType.OK) { 
         BookingData.masterList.remove(selected);
        showAlert(Alert.AlertType.INFORMATION, "Record Extracted", "Selected entry has been removed!");

       }
      //if cancel is selected nothing happens and message below is displayed
      
       if(result.get() == ButtonType.NO) {
        showAlert(Alert.AlertType.INFORMATION, "Action Cancelled", "Selected entry has not been removed!");
       }
    }

    

        // Extends removal updates directly into the shared global array matrix loop


    //views a selected reservation entry record in a new popup to the side

    
    @FXML 
    private void handleViewReservation() {
        Reservation selected = reservationTable.getSelectionModel().getSelectedItem();

        if(selected == null) {
            showAlert(Alert.AlertType.WARNING, "Selection Required", "Please make a selection from the list of reservations!!");
            return;
         }

         //stage to display the reservation details in a fuller picture when the table is not enough to display all info

         Group root = new Group();

        //creates a stage to view Reservation details in a better view

         Stage viewer = new Stage();
         viewer.setTitle("Reservation Details");
         viewer.setResizable(true); //allows user to resize window
        

         //sets the background to a beige color screen

         Scene scn = new Scene(root, 400, 400);
         scn.setFill(Color.BEIGE);

         viewer.setScene(scn);
         viewer.show();

         //writes out the guest's username and that their details are being shown

         Label guestName = new Label("Showing details for " + selected.getGuestUsername());
         guestName.setLayoutX(20);
         guestName.setFont(Font.font(20));

         
    
         //writes out the room type they purchased

         Label room = new Label("Room Type: " + selected.getRoomType());
         room.setFont(Font.font(15));
         room.setLayoutX(20);
         room.setLayoutY(35);

         //writes out their check in date

         Label cIn = new Label("Check In Date: " + selected.getCheckIn());

         cIn.setFont(Font.font(15));
         cIn.setLayoutX(20);
         cIn.setLayoutY(55);

         //writes out the check out date

         Label cOut = new Label("Check Out Date: " + selected.getCheckOut());
         cOut.setFont(Font.font(15));
         cOut.setLayoutX(20);
         cOut.setLayoutY(85);

         //writes the status of their booking

         Label status = new Label("Booking status: " + selected.getStatus());
         status.setFont(Font.font(15));
         status.setLayoutX(20);
         status.setLayoutY(115);

         
         // writes the total cost of their booking in dollars
         Label totalCost = new Label("Total Cost: $" + selected.getTotalCost());
            totalCost.setFont(Font.font(15));
            totalCost.setLayoutX(20);
            totalCost.setLayoutY(145);

         //initializes roomNum as an int 
        int roomNum = selected.getRoomNumber();

        //creates a label for roomNumber
        Label roomNumber;
        
        //if room Number is 0, in Reservation Details it is shown as N/A
        if(roomNum == 0) {
            roomNumber = new Label("Room #: N/A");

        } else {

            //if there is a room number assigned, the label is shown in this form
            roomNumber = new Label("Room #: " + roomNum);
        }

        //sets up the dimensions of the label
        roomNumber.setFont(Font.font(15));
        roomNumber.setLayoutX(20);
        roomNumber.setLayoutY(175);



        

        //calls out all the labels in this class
        
         root.getChildren().addAll(guestName,room, cIn, cOut, status, totalCost, roomNumber); 
       

    }

    //class to assign room for guests 
     @FXML 
    public void assignRoom() {

        Reservation selected = reservationTable.getSelectionModel().getSelectedItem();

        //an entry must be selected from the table in order for this method to work 
        //in cases where nothing is selected, it displays an alert on screen 

        if(selected == null) {
            showAlert(Alert.AlertType.WARNING, "Selection Required", "Please make a selection from the list of reservations!!");
            return;
         }

        

          Group root = new Group();

        //creates a stage to view a dropdown menu with all room options and a confirm button  

         Stage viewer = new Stage();
         viewer.setTitle("Rooms Available");
         viewer.setResizable(false); //allows user to resize window
        

         //sets up the background and color

         Scene scn = new Scene(root, 400, 400);
         scn.setFill(Color.WHITESMOKE);

         viewer.setScene(scn);
         viewer.show();

         //dropdown menu is created to display room numbers
         rooms = new ComboBox<>();

         //0 is listed as the option for not assigned, when customers book. They are auto-assigned 0

         rooms.getItems().addAll("0", "1","2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16","17","18","19", "20");


         //program loops thru the booking data and searches for which number is taken
         for(Reservation rsv: BookingData.masterList) {
            int tkn = rsv.getRoomNumber();
            
            //for those that are not 0 and taken, they are removed from the dropdown options
            //Ex: if 2 is taken, the options will no longer show 2. 

            if(tkn !=0) { 
                rooms.getItems().remove(String.valueOf(tkn)); 

            }
         }

         //sets up the dimensions and position of the dropdown box on the stage popup
         rooms.setLayoutX(40);
         rooms.setLayoutY(50);
         rooms.setPrefWidth(200);

         //creates the confirm button and its dimensions and sets the text on the button to display Confirm
         Button confirm = new Button();

         confirm.setLayoutX(40);
         confirm.setLayoutY(90);
         confirm.setText("Confirm");

         
         //when the button is clicked, the confirmButton executes

         confirm.setOnAction(event ->{

            confirmButton();
         });
         
         

         root.getChildren().addAll(rooms, confirm); //calls for the dropdown menu and confirm button to show up on stage

        
    }

    //program for confirmButton that was called in the method earlier

    //confirms and locks in the assigned room that is chosen from the dropdown menu above 

    private void confirmButton() {


         Reservation selected = reservationTable.getSelectionModel().getSelectedItem();

         //shown was string chosen due to numbers in dropdown being written as "0", "1", etc.
         String chosen = rooms.getValue(); 

         //checks if a room is selected, and tells user to select from dropdown meny 

         if(chosen == null) {
            showAlert(Alert.AlertType.WARNING, "No selection", "Please select a room from the options in dropdown menu");
            return;

         } 

         //sets the room number as an integer due to it being a String type ("3") in the dropdown
         int roomNum = Integer.valueOf(chosen);

        //sets and locks in the room number that is selected from the dropdown once confirm button is hit
       selected.setRoomNumber(roomNum);

       //displays message to show that the room has been assigned
       showAlert(Alert.AlertType.INFORMATION, "Assigned", "Room #" + roomNum + " has been assigned!");

         

         


        
    }




    

    /**
     * Locks terminal view controls and switches the app scene root back to the splash welcome page.
     */
    @FXML
    private void handleLogout() {
        SceneManager.switchTo("WelcomeView.fxml", "Welcome to Hotel Nexus");
    }

   

    /**
     * Standard message alert generator utility.
     */
    private void showAlert(Alert.AlertType type, String title, String contents) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(contents);
        alert.showAndWait();
    }
}
