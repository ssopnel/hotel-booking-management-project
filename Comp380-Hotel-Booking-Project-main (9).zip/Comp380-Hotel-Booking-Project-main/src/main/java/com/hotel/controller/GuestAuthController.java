package com.hotel.controller;

import com.hotel.Guest;
import com.hotel.SceneManager;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import java.util.HashMap;
import java.util.Map;

/*
Class to allow guest to login and authentication from site
*/
public class GuestAuthController 
{
    //Mapped the fields with proper date from FXML file
    @FXML private TextField loginUsernameField;
    @FXML private PasswordField loginPasswordField;
    
    @FXML private TextField regNameField;
    @FXML private TextField regEmailField;
    @FXML private TextField regUsernameField;
    @FXML private PasswordField regPasswordField;
    
    //Display message at bottom of the screen based input
    @FXML private Label statusLabel; 

    //Temp memory databased due to frontend. (Need to change based on the backend)
    private static final Map<String, Guest> userDatabase = new HashMap<>();
    
    
    //Variable to display the login status as the current profile login
    public static String loggedInUser = "Guest";

    /*
    Initialize the controller. Basic guest profile (Same as the staff login but is not needed. check with sopnel)
    */
    @FXML
    public void initialize() 
    {
        if (userDatabase.isEmpty()) 
        {
            userDatabase.put("traveler7", new Guest("John Doe", "john.doe@gmail.com", "password123"));
        }
    }

    /*
    Runs when user clicks sign in. Checks for username and password match.
    */
    @FXML
    private void handleLogin() 
    {
        
        //variables for user name and password
        String username = loginUsernameField.getText().trim();
        String password = loginPasswordField.getText();

        //A check to see if username or password is empty and displays proper error message
        if (username.isEmpty() || password.isEmpty()) 
        {
            showStatus("Please enter both username and password fields.", "red");
            return;
        }

        
        //Checks if username and password matches
        //Display proper status message
        if (userDatabase.containsKey(username) && userDatabase.get(username).getPassword().equals(password)) 
        {
            //displays current username in variable
            loggedInUser = username; 
            showStatus("Access approved! Redirecting...", "green");
            
            
            //Send to guest booking window
            SceneManager.switchTo("GuestDashboard.fxml", "Guest Booking Dashboard");
        } 
        
        else 
        {
            //display error message if not properly matching
            showStatus("Invalid credentials. Enter your registered username and password.", "red");
        }
    }

    /*
    Method to allow guest to register a new account. 
    */
    @FXML
    private void handleRegister() 
    {
        String name = regNameField.getText().trim();
        String email = regEmailField.getText().trim();
        String username = regUsernameField.getText().trim();
        String password = regPasswordField.getText();

        
        //A catch to see is any field was empty and display the error message
        if (name.isEmpty() || email.isEmpty() || username.isEmpty() || password.isEmpty()) 
        {
            showStatus("All registration parameters are required.", "red");
            return;
        }


        //A catch to see if username is taken and display error message
        if (userDatabase.containsKey(username)) 
        {
            showStatus("Username already taken. Please choose another username.", "red");
        } 
        
        else 
        {
            
            //Gets user information and creates profile (need to change due to backend only temp due to front end)
            //Display message to inform user that profile has been made
            userDatabase.put(username, new Guest(name, email, password)); 
            showStatus("Registration Complete! Sign in with your username.", "green");
            
            //Clear out the fields for future registration
            regNameField.clear();
            regEmailField.clear();
            regUsernameField.clear();
            regPasswordField.clear();
        }
    }

    /*
    Send back to the main window
    */
    @FXML
    private void handleBack() 
    {
        //note hotel needs to be change
        SceneManager.switchTo("WelcomeView.fxml", "Welcome to Hotel");
    }

    /*
     Format status message based on user input
    */
    private void showStatus(String message, String color) 
    {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: " + color + ";");
    }
}

//check in the team to see what is the hotel name and change it.
//check with sopnel if the it needs to be change or any improvements. 
