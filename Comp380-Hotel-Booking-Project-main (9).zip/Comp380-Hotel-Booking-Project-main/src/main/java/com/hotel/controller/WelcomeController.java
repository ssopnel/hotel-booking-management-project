package com.hotel.controller;

import com.hotel.SceneManager;
import javafx.fxml.FXML;

/*
 Handles the windows and switches to the proper input screen.
*/
public class WelcomeController
{
    /*
     Sends the employee to the staff login window.
    */
    @FXML
    private void handleEmployeePortal()
    {
        SceneManager.switchTo("EmployeeLogin.fxml", "Employee Login");
    }

    /*
     Sends the guest to the guest login window.
    */
    @FXML
    private void handleGuestPortal()
    {
        SceneManager.switchTo("GuestAuth.fxml", "Guest Login");
    }
}
