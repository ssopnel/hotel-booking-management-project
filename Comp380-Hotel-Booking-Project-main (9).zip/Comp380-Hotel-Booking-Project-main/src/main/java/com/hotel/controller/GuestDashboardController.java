package com.hotel.controller;

import com.hotel.SceneManager;
import com.hotel.Reservation;
import com.hotel.BookingData;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;


import java.time.temporal.ChronoUnit;

/*
 Class for the guest booking window and proper variables
*/
public class GuestDashboardController 
{

    //variables for the booking 
    @FXML private DatePicker checkInDate;
    @FXML private DatePicker checkOutDate;
    @FXML private ComboBox<String> roomTypeBox;
    @FXML private Label welcomeUserLabel; // Header text tracking the active profile name
    @FXML private ComboBox<Integer> guestsBox; 
    @FXML private Label estCost;

    /*
    
     Populates menu fields and personalizes header panels upon interface loading.
    */
    @FXML
    public void initialize() 
    {
      
        //Basic room types and current prices. (check with team what types)
        //Need to add smoking button
        roomTypeBox.getItems().addAll("Single Room ($100/N)", "Double Room ($150/N)", "Suite ($300/N)");

        guestsBox.getItems().addAll(1,2,3,4,5, 6); //capped at 6 for max occupancy. 
        
       
        //Change the status name with current login guest. 
        if (welcomeUserLabel != null) 
        {
            welcomeUserLabel.setText("Welcome, " + GuestAuthController.loggedInUser + "!");
        }
    }

    /*
    Method to handle reservations and stores in list.
    Displays proper bookings if successful
    */
    @FXML
    public void handleBookRoom() 
    {
        
        //checks to see if there are any missing values for any parameters 
        if (checkInDate.getValue() == null || checkOutDate.getValue() == null || roomTypeBox.getValue() == null || guestsBox.getValue() == null) 
        {
            //displays a warning to user if any fields are missing

            showAlert(Alert.AlertType.WARNING, "Missing Fields", "Please complete all booking selections.");
            return;
        }

        
        //checks if the check in date matches the check out date 

        if (checkInDate.getValue().isEqual(checkOutDate.getValue())) {

        //displays a warning to user if the dates are the same

            showAlert(Alert.AlertType.WARNING, "Dates Invalid" , "Check in and Check out dates cannot be the same!!");
            return;
        }


        //checks if the check out date is before check in date

        if (checkOutDate.getValue().isBefore(checkInDate.getValue())) {

            //displays a warning to user indicating the dates are not valid

            showAlert(Alert.AlertType.WARNING, "Dates Invalid", "Check out date cannot be before check in date!!");
            return;
        }

        //checks if guest count meets room requirements
        if(guestsBox.getValue() > 1 && roomTypeBox.getValue().contains("Single")) {
            
            //throws an error if party is too big for room based on the value for number of guests

            showAlert(Alert.AlertType.WARNING, "Room Invalid", "Your group size is too big! Please consider upgrading to Double or Suite.");
            return;
        }

            else if(guestsBox.getValue() > 2 && roomTypeBox.getValue().contains("Double")) {

                showAlert(Alert.AlertType.WARNING, "Room Invalid", " Your group size is too big! Please consider upgrading to Suite.");
                return;

            }
        


            //long type is used due to chrono unit restrictions
            //finds the number of nights by computing the number of days between check in and check out

            long nights = ChronoUnit.DAYS.between(checkInDate.getValue(), checkOutDate.getValue());

            double totalCost = 0.00; //initializes totalCost to $0.00
        
        //checks if the room type contains Single 

        if(roomTypeBox.getValue().contains("Single")) {
        
          totalCost = (int) nights * 100; 
          estCost.setText( "$" + totalCost);

        //checks if the room type is a double
        } else if(roomTypeBox.getValue().contains("Double")) {

            totalCost = (int) nights * 150;
            estCost.setText("$" + totalCost);

        }

        //checks if the room type is a suite
        else if(roomTypeBox.getValue().contains("Suite")) {

            totalCost = (int) nights * 300;
            estCost.setText("$" + totalCost);
        }
         
    


    
        // Append a new reservation entity directly to our globally synchronized master list array

        //Attach the new reservation on the booking list(note need to change due to backend and how booking will be looked at in staff side. check with sopnel)
        BookingData.masterList.add(new Reservation(
            GuestAuthController.loggedInUser,
            roomTypeBox.getValue(),
            checkInDate.getValue().toString(),
            checkOutDate.getValue().toString(),              
            "Confirmed",
            totalCost, 0
            
        ));
        
        
        
        //Display proper booking information with the input from guest
        showAlert(Alert.AlertType.INFORMATION, "Booking Completed", 
            "Successfully booked for user: " + GuestAuthController.loggedInUser + "\n" +
            "Room: " + roomTypeBox.getValue() + "\nFrom: " + checkInDate.getValue() + " to " + checkOutDate.getValue() + "\n" +
            "Number of Guests: " + guestsBox.getValue() + "\n" + 
            "Total Cost: " + totalCost);

        
            
        // Clears out data for new reservations
       
        
         checkInDate.setValue(null);
        checkOutDate.setValue(null);
        roomTypeBox.setValue(null);
        guestsBox.setValue(null);
        estCost.setText(" ");
        
        
        }
    
 
    
    /*
     Terminates the active dashboard user session and returns to the root landing screen.

    */


    @FXML
    //change hotel name. Check in with team for what is the hotel name.
    private void handleLogout() {
        SceneManager.switchTo("WelcomeView.fxml", "Welcome to Hotel");
    }



    /*
     Method to show alerts and display message
    */
    private void showAlert(Alert.AlertType type, String title, String contents) 
    {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(contents);
        alert.showAndWait();
    }

}

