package com.hotel.controller;

import com.hotel.SceneManager;
import com.hotel.Employee;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import java.util.HashMap;
import java.util.Map;

/*
 class to allow staff to login and display staff site with authentication
*/
public class EmployeeLoginController 
{
    // FXML fields mapped to entry text boxes in EmployeeLogin.fxml
    //Proper FXML fields to text box form the FXML file 
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    
    // FXML fields for new employee registration rows
    @FXML private TextField regEmpNameField;
    @FXML private TextField regEmpEmailField;
    @FXML private TextField regUsernameField;
    @FXML private PasswordField regPasswordField;
    
    //display error message if input is wrong
    @FXML private Label errorLabel; 

    
    //A temp database for store staff data(Needs to change due to backend)
    private static final Map<String, Employee> staffDatabase = new HashMap<>();
    
    // variable to authicate staff instead of
    public static String loggedInStaff = "Staff Member";

    /*
    Initialize the controller. Basic admin profile. (saw on other examples and thought it was a good idea. however not needed. check with sopnel)
    */
    @FXML
    public void initialize() 
    {
        if (staffDatabase.isEmpty()) 
        {
            staffDatabase.put("admin", new Employee("Administrator", "admin@hotel.com", "password"));
        }
    }

    /*
    Checks and validate staff login based on the local memory
    */
    @FXML
    private void handleLogin() 
    {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();

        //A check due to empty fields and displays error message 
        if (username.isEmpty() || password.isEmpty()) 
        {
            showStatus("Please enter both username and password fields.", "red");
            return;
        }

        // Check if the username key exists and compare passwords
        if (staffDatabase.containsKey(username) && staffDatabase.get(username).getPassword().equals(password)) 
        {
            //shows the current active username
            loggedInStaff = username; 
            
            //Displays if proper staff login and who is login
            showStatus("Staff Authentication Approved! Session active for " + username + ".", "green");
            

        
            // NOTE: The scene redirection line below is commented out to lock interactions to this portal frame
            SceneManager.switchTo("EmployeeDashboard.fxml", "Staff Management Terminal");
        } 
        
        else 
        {
            //Displays error message if improper login
            showStatus("Invalid staff credentials matching that username.", "red");
        }
    }

    /*
    method to handle registration for new staff
    */

    @FXML
    private void handleRegister() {
        String fullName = regEmpNameField.getText().trim();
        String email = regEmpEmailField.getText().trim();
        String username = regUsernameField.getText().trim();
        String password = regPasswordField.getText();

        // A catch if staff has any fields empty and display proper message.
        if (fullName.isEmpty() || email.isEmpty() || username.isEmpty() || password.isEmpty()) 
        {
            showStatus("All staff enrollment fields are mandatory.", "red");
            return;
        }

        //A catch if the username is already taken and display message
        if (staffDatabase.containsKey(username)) 
        {
            showStatus("Username already taken by another team member.", "red");
        } 
        else 
        {
            
            //Gets user information and creates profile (need to change due to backend only temp due to front end)
            //Display message to inform employee that profile has been made
            staffDatabase.put(username, new Employee(fullName, email, password));
            showStatus("Employee registration complete! Log in via your username.", "green");
            
            //Clear out the fields for future registration
            regEmpNameField.clear();
            regEmpEmailField.clear();
            regUsernameField.clear();
            regPasswordField.clear();
        }
    }

    /*
    Sends window to main site 
    */
    @FXML
    private void handleBack() 
    {
        //note name of hotel needs to be change. 
        SceneManager.switchTo("WelcomeView.fxml", "Welcome to Hotel"); 
    }

    /*
    Format status message based on layout
    */
    private void showStatus(String message, String color) 
    {
        errorLabel.setText(message);
        errorLabel.setStyle("-fx-text-fill: " + color + ";");
    }
}

