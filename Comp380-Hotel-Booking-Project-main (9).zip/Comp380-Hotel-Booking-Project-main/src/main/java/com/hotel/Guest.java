package com.hotel;

//class to hold guest data

public class Guest {

    //variables needed for the guest
    private String fullName; 
    private String email;    
    private String password; 

    /*
     pointer to reference data of guest
    */
    public Guest(String fullName, String email, String password) 
    {
        this.fullName = fullName;
        this.email = email;
        this.password = password;
    }

    
    //method to get variable data and return
    public String getFullName() { return fullName; }
    public String getEmail()    { return email; }
    public String getPassword() { return password; }
}

//based on 8/3/26 feedback
//consult with backend and see what is need to properly connect the files