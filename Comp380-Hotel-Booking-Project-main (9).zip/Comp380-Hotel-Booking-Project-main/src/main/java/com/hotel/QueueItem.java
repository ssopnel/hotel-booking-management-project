package com.hotel;
public class QueueItem{
	
	private Reservation data;
	private QueueItem next;
	
	public QueueItem(Reservation data){
		this.data = data;
	}
	
	public QueueItem getNext(){
		return next;
	}
	
	public void setNext(QueueItem item){
		this.next = item;
	}
	
	public void setData(Reservation data){
		this.data = data;
	}
	
	public Reservation getData(){
		return data;
	}
	
	
}