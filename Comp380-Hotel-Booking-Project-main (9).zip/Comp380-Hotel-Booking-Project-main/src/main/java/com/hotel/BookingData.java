package com.hotel;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/*
Provides a shared global data matrix visible across separate workspace view portals.
Enables client bookings to display immediately within the administration interface.
class for booking data that is viewable to guest and staff
allows for staff to see what is avaible to change
*/
public class BookingData 
{
    //List to show some examples of people in the hotel and booking infomation
    public static final ObservableList<Reservation> masterList = FXCollections.observableArrayList
    (
        new Reservation("michael_rodriguez", "Suite ($300/N)", "2026-08-10", "2026-08-15", "Confirmed", 1500.00, 0),
        new Reservation("lupe_jara", "Single Room ($100/N)", "2026-09-01", "2026-09-04", "Checked In", 300.00, 2)
    );
}

