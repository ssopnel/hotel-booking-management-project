
package com.hotel;
/** Login info used to access application. Once login info is confirmed, finds user data using ID. Uses isEmployee to specify which file users data is stored under.
 *
 * @author Max Brown
 * 
 */
public class Login implements Identifiable{
	
	/** Username set by user. Used as identifier. Must be unique. */
	private String username; 
	/** Password set be user. */
	private String password;
	/** Represents if Login belongs to employee. */
	private boolean isEmployee; 
	/** Links user data with user login in text files. */
	private int ID; 
	
	/** Creates new Login with specified username and password. 
	 * Specifies if new Login is for employee.
	 * Creates new ID that is not already used.
	 *
	 * @param username Username set by user.
	 * @param password password set by user.
	 * @param isEmployee Whether login belongs to employee.
	 *
	 */
	public Login(String username, String password, boolean isEmployee){
		this.username = username;
		this.password = password;
		this.isEmployee = isEmployee;
		int random;
		while(true){
			random = (int) (Math.random() * 100000000); //random int between 0 (inclusive)and 100,000,000 (exclusive)
			String randomString = String.valueOf(random);
			LoginDao logindao = new LoginDao();
			if(logindao.searchID(randomString) == false){
				ID = random;
				break;
			}
		}			 
	}

	/** Constructor used by LoginDao */
	public Login(String username, String password, boolean isEmployee, int ID){
		this.username = username;
		this.password = password;
		this.isEmployee = isEmployee;
		this.ID = ID;
	}

	/** Blank constructor used for error handling. */
	public Login(){
		this.username = null;
	}
	/** 
	 * Gets unique identifier of object.
	 * @return Unique identifier as String.
	 */
	public String getIdentifier(){
		return username;
	}
	
	/**
	 * Gets username of created by user.
	 @return Username created by user.
	 */
	protected String getUsername(){
		return username;
	}
	
	/**
	 * Gets password made by user.
	 * @return Password made by user.
	 */
	protected String getPassword(){
		return password;
	}
	
	/**
	 * Gets ID of user.
	 * @return ID associated with this login.
	 */
	protected int getID(){
		return ID;
	}
	
	/**
	 * Get employee status as boolean.
	 * @return Employee status as boolean.
	 */
	protected boolean getIsEmployee(){
		return isEmployee;
	}
}