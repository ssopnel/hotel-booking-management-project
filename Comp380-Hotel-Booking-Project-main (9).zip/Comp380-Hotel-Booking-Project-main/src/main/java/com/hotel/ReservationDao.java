package com.hotel;
import java.time.LocalDate;
//dao class for Reservation objects
//reads and writes reservations to data/reservations.txt
//customer ID and Room Number are how a reservation points at a customer and a room
//joseph wythe
public class ReservationDao extends Dao<Reservation>{
        
		private String filePath = "data/reservations.txt";
        private String[] attributes = {"Reservation ID", "Customer ID","Room Type", "Room Number", "Check-in Date", "Check-out Date", "Status"};
        
		public ReservationDao(){
    
        }
        
        protected String[] convert(Reservation t){
            String[] variables = new String[attributes.length];
            variables[0] = String.valueOf(t.getReservationID());
            variables[1] = String.valueOf(t.getCustomerID());
            variables[2] = t.getRoomType();
            variables[3] = String.valueOf(t.getRoomNumber());
            variables[4] = t.getCheckInDate().toString();
            variables[5] = t.getCheckOutDate().toString();
            variables[6] = t.getStatus();
            return variables;
        }
        //builds a Reservation from the array of Strings read out of the file
        //parses the numbers back out and passes the dates and status through
        protected Reservation convert(String[] variables){
            if(variables[0] == null){
                return new Reservation();
            }
            int reservationID = Integer.parseInt(variables[0]);
            int customerID = Integer.parseInt(variables[1]);
            String roomType = variables[2];
            int roomNumber = Integer.parseInt(variables[3]);
			LocalDate checkInDate = LocalDate.parse(variables[4]);
			LocalDate checkOutDate = LocalDate.parse(variables[5]);
            String status = variables[6];
            return new Reservation(reservationID, customerID, roomType, roomNumber, checkInDate, checkOutDate, status);
        }

        protected String getFilePath(){
            return filePath;
        }

        protected String[] getAttributes(){
            return attributes;
        }
    }