package com.hotel;
//joseph wythe
//dao class for employee objects
//reads and writes employee objects to data/employees.txt
public class EmployeeDao extends Dao<Employee>{
    
        private String filePath = "data/employees.txt";
        private String[] attributes = {"Employee ID", "First Name", "Last Name", "Email", "Position"};
    
        public EmployeeDao(){
    
        }
        //converts employee into an array of strings
        //employee ID turned into a string
        protected String[] convert(Employee t){
            String[] variables = new String[attributes.length];
            variables[0] = String.valueOf(t.getEmployeeID());
            variables[1] = t.getFirstName();
            variables[2] = t.getLastName();
            variables[3] = t.getEmail();
            variables[4] = t.getPosition();
            return variables;
        }
        //converts an array of strings into an employee object
        //returns an invalid employee if nothing is found
        protected Employee convert (String[] variables){
            if(variables[0] == null){
                return new Employee();
            }
            int employeeID = Integer.parseInt(variables[0]);
            return new Employee(employeeID, variables[1], variables[2], variables[3], variables[4]);
        }

        protected String getFilePath(){
            return filePath;
        }

        protected String[] getAttributes(){
            return attributes;
        }
}