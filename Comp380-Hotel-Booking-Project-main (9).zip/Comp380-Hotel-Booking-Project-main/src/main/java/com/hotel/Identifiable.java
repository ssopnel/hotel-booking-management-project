package com.hotel;
/** Objects that implement identifiable have a getIdentifier() method that is used in Dao. 
 * @author Max Brown
 */
public interface Identifiable{
	/** Gets unique identifying variable of the object.
	 * @return The unique identifying variable as a String.
	 */
	public String getIdentifier();
}