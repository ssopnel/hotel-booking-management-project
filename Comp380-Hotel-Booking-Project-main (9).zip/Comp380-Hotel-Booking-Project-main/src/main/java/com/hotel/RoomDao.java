package com.hotel;
/** Dao class for Room. Stores room objects in text file.
 *
 * @author Max Brown
 */

public class RoomDao extends Dao<Room>{
	/** File path where Room objects are stored. */
	private String filePath = "data/rooms.txt";
	/** Name of instance variables of Room objects. */
	private String[] attributes = {"Room Number","Room Type","Smoking","Handicap"};
	
	/** Constructor */
	public RoomDao(){
	
	}
	
	/**
	 * Converts Room object into Array containing its instance variables as Strings.
	 * @param t Room object being converted.
	 * @return Array of Strings that represent t's instance variables.
	 */
	protected String[] convert(Room t){
		String[] variables = new String[attributes.length];
		variables[0] = String.valueOf(t.getRoomNumber());
		variables[1] = String.valueOf(t.getRoomType());
		variables[2] = String.valueOf(t.getSmoking());
		variables[3] = String.valueOf(t.getHandicap());
		return variables;
		
	}
	/** 
	 * Creates new Room object. Converts Strings in variables Array into appropriate types then calls Room constructor using those variables. 
	 * @param variables Array of Strings that contains instance variables for a Room object.
	 * @return Room object created using Strings from variables Array.
	 */
	protected Room convert(String[] variables){
		if(variables[0] == null){
			return new Room();
		}
		int roomNumber = Integer.parseInt(variables[0]);
		String roomType = variables[1];
		boolean smoking = Boolean.parseBoolean(variables[2]);
		boolean handicap = Boolean.parseBoolean(variables[3]);
		return new Room(roomNumber, roomType, smoking, handicap);
	}
	
	/**
	 * Gets file path where Room objects are stored.
	 * @return File path where Room objects are stored as String.
	 */
	protected String getFilePath(){
		return filePath;
	}
	
	/**
	 * Gets attributes Array.
	 * @return Array of Strings which represent the names of instance variables for Room.
	 */
	protected String[] getAttributes(){
		return attributes;
	}
}