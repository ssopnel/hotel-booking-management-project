package com.hotel;
import java.time.LocalDate;
//joseph wythe

public class Reservation implements Identifiable{
    
	private int reservationID;
    private int customerID;
    private String roomType;
    private int roomNumber;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    private String status;
    private String guestUsername;
    private double totalCost;

    //Constructor used by ReservationDao
    public Reservation(int reservationID, int customerID, String roomType, int roomNumber, LocalDate checkInDate, LocalDate checkOutDate, String status){
        this.reservationID = reservationID;
        this.customerID = customerID;
        this.roomType = roomType;
        this.roomNumber = roomNumber;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.status = status;
    }

    //Constructor for new Reservations
    public Reservation(int customerID, String roomType, String checkInDate, String checkOutDate){
        int randomID;
        ReservationDao dao = new ReservationDao();
        while(true){
            randomID = (int)(Math.random() * 100000);
            if(dao.searchID(String.valueOf(randomID)) == false){
                break;
            }
        }
        this.reservationID = randomID;
        this.customerID = customerID;
        this.roomType = roomType;
        this.checkInDate = LocalDate.parse(checkInDate);
        this.checkOutDate = LocalDate.parse(checkOutDate);
        this.status = "Awaiting Confirmation.";
    }

    public Reservation(int reservationID, int customerID, String roomType, int roomNumber, String checkInDate, String checkOutDate, String status){
        this.reservationID = reservationID;
        this.customerID = customerID;
        this.roomType = roomType;
        this.roomNumber = roomNumber;
        this.checkInDate = LocalDate.parse(checkInDate);
        this.checkOutDate = LocalDate.parse(checkOutDate);
        this.status = status;
    }

    public Reservation(String guestUsername, String roomType, String checkInDate, String checkOutDate, String status, double totalCost, int roomNumber){
        this.guestUsername = guestUsername;
        this.roomType = roomType;
        this.checkInDate = LocalDate.parse(checkInDate);
        this.checkOutDate = LocalDate.parse(checkOutDate);
        this.status = status;
        this.totalCost = totalCost;
        this.roomNumber = roomNumber;
    }
	
    //Constructor for error handling
    public Reservation(){
        this.reservationID = -1;
    }

    public double calculatePrice(){
        return 0.0;
    }
    
	
	/** 
	 * Checks if Reservation date conflicts with other reservation.
	 * @param other Reservation being compared to.
	 * @return Whether the two reservations are conflicting.
	 */
	public boolean conflictsWith(Reservation other){
		LocalDate aCheckIn = this.checkInDate;
		LocalDate bCheckIn = other.getCheckInDate();
		LocalDate aCheckOut = this.checkOutDate;
		LocalDate bCheckOut = other.getCheckOutDate();
		
		if(aCheckIn.isBefore(bCheckOut) && bCheckIn.isBefore(aCheckOut)){
			return true;
		}
		return false;
	}
	
	/**
	 * Checks if this Reservation occurs completely after other Reservation.
	 * Allows start of one and end of other to be equal.
	 * @param other Reservation being compared to.
	 * @return True if this Reservation occurs after the other.
	 */
	public boolean isAfter(Reservation other){
		if(this.checkInDate.isAfter(other.getCheckOutDate()) || this.checkInDate.isEqual(other.getCheckOutDate())){
			return true;
		}
		else{
			return false;
		}
	}
	
	/**
	 * Checks if this Reservation occurs completely before other Reservation.
	 * Allows start of one and end of other to be equal.
	 * @param other Reservation being compared to.
	 * @return True if this Reservation occurs before the other.
	 */
	public boolean isBefore(Reservation other){
		if(this.checkOutDate.isBefore(other.getCheckInDate()) || this.checkOutDate.isEqual(other.getCheckInDate())){
			return true;
		}
		else{
			return false;
		}
	}

    public int getReservationID(){
        return this.reservationID;
    }

    public int getCustomerID(){
        return this.customerID;
    }

    public String getRoomType(){
        return this.roomType;
    }

    public int getRoomNumber(){
        return this.roomNumber;
    }

    public LocalDate getCheckInDate(){
        return this.checkInDate;
    }

    public LocalDate getCheckOutDate(){
        return this.checkOutDate;
    }

    public String getStatus(){
        return this.status;
    }

    public String getGuestUsername(){
        return this.guestUsername;
    }

    public LocalDate getCheckIn(){
        return this.checkInDate;
    }

    public LocalDate getCheckOut(){
        return this.checkOutDate;
    }

    public double getTotalCost(){
        return this.totalCost;
    }

    public void setRoomNumber(int roomNumber){
        this.roomNumber = roomNumber;
    }

    public void setCheckInDate(String checkInDate){
        this.checkInDate = LocalDate.parse(checkInDate);
    }

    public void setCheckOutDate(String checkOutDate){
        this.checkOutDate = LocalDate.parse(checkOutDate);
    }

    public void setStatus(String status){
        this.status = status;
    }

    public String getIdentifier(){
        return String.valueOf(this.reservationID);
    }
}
