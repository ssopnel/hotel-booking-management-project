package com.hotel;
//joseph wythe
public class CustomerDao extends Dao<Customer>{
    
        private String filePath = "data/customers.txt";
        private String[] attributes = {"Customer ID", "First Name", "Last Name", "Email", "Phone Number"};
    
        public CustomerDao(){
    
        }
    
        protected String[] convert(Customer t){
            String[] variables = new String[attributes.length];
            variables[0] = String.valueOf(t.getCustomerID());
            variables[1] = t.getFirstName();
            variables[2] = t.getLastName();
            variables[3] = t.getEmail();
            variables[4] = t.getPhoneNumber();
            return variables;
        }
    
        protected Customer convert(String[] variables){
            if(variables[0] == null){
                return new Customer();
            }
            int customerID = Integer.parseInt(variables[0]);
            String firstName = variables[1];
            String lastName = variables[2];
            String email = variables[3];
            String phoneNumber = variables[4];
            return new Customer(customerID, firstName, lastName, email, phoneNumber);
        }

    
        protected String getFilePath(){
            return filePath;
        }
    
        protected String[] getAttributes(){
            return attributes;
        }
}