package com.hotel;
import java.util.ArrayList;

//joseph wythe
//holds the hotel's rooms and reservations while the program is running
//rooms and reservations are still stored in their text files, this just keeps
//them in memory so they can be linked together and searched
public class Hotel{

    private String hotelName;
    private ArrayList<Room> rooms;
    private ArrayList<Reservation> reservations;

    private RoomDao roomDao = new RoomDao();
    private ReservationDao reservationDao = new ReservationDao();

    public Hotel(String hotelName){
        this.hotelName = hotelName;
        this.rooms = new ArrayList<Room>();
        this.reservations = new ArrayList<Reservation>();
    }

    //writes the room to the text file right away, then keeps it in the list
    public void createRoom(Room r){
        roomDao.create(r);
        rooms.add(r);
    }

    //writes the reservation to the text file right away, then keeps it in the list
    public void createReservation(Reservation r){
        reservationDao.create(r);
        reservations.add(r);
    }

    public void loadRooms(){
        rooms = roomDao.readAll();
    }


    public void loadReservations(){
        reservations = reservationDao.readAll();
    }

    public void linkReservations(){
        for(int i = 0; i < reservations.size(); i++){
            Reservation res = reservations.get(i);
            Room room = findRoom(res.getRoomNumber());
            if(room.getRoomNumber() != -1){
                room.addReservation(res);
            }
        }
    }

    //finds a room in the list by its number, returns an invalid room if it is not there
    public Room findRoom(int roomNumber){
        for(int i = 0; i < rooms.size(); i++){
            if(rooms.get(i).getRoomNumber() == roomNumber){
                return rooms.get(i);
            }
        }
        return new Room();
    }

    public String getHotelName(){
        return this.hotelName;
    }

    public ArrayList<Room> getRooms(){
        return this.rooms;
    }

    public ArrayList<Reservation> getReservations(){
        return this.reservations;
    }
}
